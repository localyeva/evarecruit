<?php
/*
Plugin Name: Demo to show Ajax interaction
Plugin URI: http://amiworks.co.in/talk//
Description: It demonstrate the use of ajax with plugins., it shows itself below the Write New POST form
Author: Amit kumar singh
Version: 1.0
Author URI: http://amiworks.co.in/talk
	
*/

add_action('wp_ajax_ak_attach', 'ajaxResponse');
add_action('edit_form_advanced', 'ajaxDemo');

function ajaxDemo()
{
	echo'<script src="'.get_option('siteurl'). '/wp-content/plugins/jquery-1.2.3.min.js"> </script>
		<script>
			function sendAjaxRequest()
			{
				$.post("'.get_option('siteurl').'/wp-admin/admin-ajax.php", {action:"ak_attach", "cookie": encodeURIComponent(document.cookie)}, function(str)	{
       alert(str);
	});
			}
		</script>
		<input type="button" value="Send Ajax Request." onclick="sendAjaxRequest();">
	';
}

function ajaxResponse()
{
	global $wpdb; 	global $userdata;  
	
	get_currentuserinfo(); 
	echo "Hello ". $userdata->user_login;
	exit;
}