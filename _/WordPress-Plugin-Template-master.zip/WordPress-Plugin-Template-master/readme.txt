=== WordPress Plugin Template ===
Contributors: hlashbrooke
Donate link: http://www.hughlashbrooke.com/donate
Tags: wordpress, plugin, template
Requires at least: 3.9
Tested up to: 4.0
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This is where you craft a short, punchy description of your plugin

== Description ==

This is where you can give a much longer description of your plugin that you can use to explain just how it awesome it really is.

== Installation ==

Installing "WordPress Plugin Template" can be done either by searching for "WordPress Plugin Template" via the "Plugins > Add New" screen in your WordPress dashboard, or by using the following steps:

1. Download the plugin via WordPress.org
1. Upload the ZIP file through the 'Plugins > Add New > Upload' screen in your WordPress dashboard
1. Activate the plugin through the 'Plugins' menu in WordPress

== Screenshots ==

1. Description of first screenshot named screenshot-1
2. Description of second screenshot named screenshot-2
3. Description of third screenshot named screenshot-3

== Frequently Asked Questions ==

= What is the plugin template for? =

This plugin template is designed to help you get started with any new WordPress plugin.

== Changelog ==

= 1.0 =
* 2012-12-13
* Initial release

== Upgrade Notice ==

= 1.0 =
* 2012-12-13
* Initial release
