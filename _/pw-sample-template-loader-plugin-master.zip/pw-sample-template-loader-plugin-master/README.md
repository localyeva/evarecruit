Sample Plugin with Template Loader
================================

This is just a simple sample plugin that illustrates how to build in a template loader in your plugin using the [Gamajo template loader class](https://github.com/GaryJones/Gamajo-Template-Loader) from Gary Jones.

See [this tutorial](http://pippinsplugins.com/template-file-loaders-plugins/) for an indepth dicussion of how template file loaders work.
