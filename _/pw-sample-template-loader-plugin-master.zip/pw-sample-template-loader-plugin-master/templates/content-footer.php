<div id="pw-footer">
	<p>This is the footer area.</p>
</div>