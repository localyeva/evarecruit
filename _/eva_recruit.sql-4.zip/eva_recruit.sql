-- phpMyAdmin SQL Dump
-- version 4.0.10deb1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Aug 25, 2015 at 03:22 PM
-- Server version: 5.6.19-0ubuntu0.14.04.1
-- PHP Version: 5.5.9-1ubuntu4.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `eva_recruit`
--

-- --------------------------------------------------------

--
-- Table structure for table `wp_commentmeta`
--

CREATE TABLE IF NOT EXISTS `wp_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `wp_comments`
--

CREATE TABLE IF NOT EXISTS `wp_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=2 ;

--
-- Dumping data for table `wp_comments`
--

INSERT INTO `wp_comments` (`comment_ID`, `comment_post_ID`, `comment_author`, `comment_author_email`, `comment_author_url`, `comment_author_IP`, `comment_date`, `comment_date_gmt`, `comment_content`, `comment_karma`, `comment_approved`, `comment_agent`, `comment_type`, `comment_parent`, `user_id`) VALUES
(1, 1, 'Mr WordPress', '', 'https://wordpress.org/', '', '2015-08-06 02:07:59', '2015-08-06 02:07:59', 'Hi, this is a comment.\nTo delete a comment, just log in and view the post&#039;s comments. There you will have the option to edit or delete them.', 0, '1', '', '', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `wp_links`
--

CREATE TABLE IF NOT EXISTS `wp_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_notes` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `wp_options`
--

CREATE TABLE IF NOT EXISTS `wp_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=424 ;

--
-- Dumping data for table `wp_options`
--

INSERT INTO `wp_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', 'http://evarecruit.localhost', 'yes'),
(2, 'home', 'http://evarecruit.localhost', 'yes'),
(3, 'blogname', 'Evolable Asia - Tuyển dụng', 'yes'),
(4, 'blogdescription', 'Evolable Asia - Tuyển dụng', 'yes'),
(5, 'users_can_register', '0', 'yes'),
(6, 'admin_email', 'khangld@evolableasia.vn', 'yes'),
(7, 'start_of_week', '1', 'yes'),
(8, 'use_balanceTags', '0', 'yes'),
(9, 'use_smilies', '1', 'yes'),
(10, 'require_name_email', '1', 'yes'),
(11, 'comments_notify', '1', 'yes'),
(12, 'posts_per_rss', '10', 'yes'),
(13, 'rss_use_excerpt', '0', 'yes'),
(14, 'mailserver_url', 'mail.example.com', 'yes'),
(15, 'mailserver_login', 'login@example.com', 'yes'),
(16, 'mailserver_pass', 'password', 'yes'),
(17, 'mailserver_port', '110', 'yes'),
(18, 'default_category', '1', 'yes'),
(19, 'default_comment_status', 'open', 'yes'),
(20, 'default_ping_status', 'open', 'yes'),
(21, 'default_pingback_flag', '1', 'yes'),
(22, 'posts_per_page', '10', 'yes'),
(23, 'date_format', 'F j, Y', 'yes'),
(24, 'time_format', 'g:i a', 'yes'),
(25, 'links_updated_date_format', 'F j, Y g:i a', 'yes'),
(26, 'comment_moderation', '0', 'yes'),
(27, 'moderation_notify', '1', 'yes'),
(28, 'permalink_structure', '/%category%/%postname%', 'yes'),
(29, 'gzipcompression', '0', 'yes'),
(30, 'hack_file', '0', 'yes'),
(31, 'blog_charset', 'UTF-8', 'yes'),
(32, 'moderation_keys', '', 'no'),
(33, 'active_plugins', 'a:9:{i:0;s:29:"acf-repeater/acf-repeater.php";i:1;s:30:"advanced-custom-fields/acf.php";i:2;s:43:"custom-post-type-ui/custom-post-type-ui.php";i:3;s:35:"jobs-management/jobs_management.php";i:4;s:37:"post-types-order/post-types-order.php";i:5;s:45:"taxonomy-terms-order/taxonomy-terms-order.php";i:6;s:37:"tinymce-advanced/tinymce-advanced.php";i:7;s:41:"wp-multibyte-patch/wp-multibyte-patch.php";i:8;s:27:"wp-pagenavi/wp-pagenavi.php";}', 'yes'),
(34, 'category_base', '', 'yes'),
(35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(36, 'advanced_edit', '0', 'yes'),
(37, 'comment_max_links', '2', 'yes'),
(38, 'gmt_offset', '0', 'yes'),
(39, 'default_email_category', '1', 'yes'),
(40, 'recently_edited', 'a:2:{i:0;s:89:"/var/www/html/evarecruit.localhost/public_html/wp-content/themes/twentyfourteen/style.css";i:1;s:0:"";}', 'no'),
(41, 'template', 'august2015', 'yes'),
(42, 'stylesheet', 'august2015', 'yes'),
(43, 'comment_whitelist', '1', 'yes'),
(44, 'blacklist_keys', '', 'no'),
(45, 'comment_registration', '0', 'yes'),
(46, 'html_type', 'text/html', 'yes'),
(47, 'use_trackback', '0', 'yes'),
(48, 'default_role', 'subscriber', 'yes'),
(49, 'db_version', '33055', 'yes'),
(50, 'uploads_use_yearmonth_folders', '1', 'yes'),
(51, 'upload_path', '', 'yes'),
(52, 'blog_public', '1', 'yes'),
(53, 'default_link_category', '2', 'yes'),
(54, 'show_on_front', 'posts', 'yes'),
(55, 'tag_base', '', 'yes'),
(56, 'show_avatars', '1', 'yes'),
(57, 'avatar_rating', 'G', 'yes'),
(58, 'upload_url_path', '', 'yes'),
(59, 'thumbnail_size_w', '150', 'yes'),
(60, 'thumbnail_size_h', '150', 'yes'),
(61, 'thumbnail_crop', '1', 'yes'),
(62, 'medium_size_w', '300', 'yes'),
(63, 'medium_size_h', '300', 'yes'),
(64, 'avatar_default', 'mystery', 'yes'),
(65, 'large_size_w', '1024', 'yes'),
(66, 'large_size_h', '1024', 'yes'),
(67, 'image_default_link_type', 'file', 'yes'),
(68, 'image_default_size', '', 'yes'),
(69, 'image_default_align', '', 'yes'),
(70, 'close_comments_for_old_posts', '0', 'yes'),
(71, 'close_comments_days_old', '14', 'yes'),
(72, 'thread_comments', '1', 'yes'),
(73, 'thread_comments_depth', '5', 'yes'),
(74, 'page_comments', '0', 'yes'),
(75, 'comments_per_page', '50', 'yes'),
(76, 'default_comments_page', 'newest', 'yes'),
(77, 'comment_order', 'asc', 'yes'),
(78, 'sticky_posts', 'a:0:{}', 'yes'),
(79, 'widget_categories', 'a:2:{i:2;a:4:{s:5:"title";s:0:"";s:5:"count";i:0;s:12:"hierarchical";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(80, 'widget_text', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(81, 'widget_rss', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(82, 'uninstall_plugins', 'a:1:{s:27:"wp-pagenavi/wp-pagenavi.php";s:14:"__return_false";}', 'no'),
(83, 'timezone_string', '', 'yes'),
(84, 'page_for_posts', '0', 'yes'),
(85, 'page_on_front', '0', 'yes'),
(86, 'default_post_format', '0', 'yes'),
(87, 'link_manager_enabled', '0', 'yes'),
(88, 'initial_db_version', '31536', 'yes'),
(89, 'wp_user_roles', 'a:5:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:62:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:9:"add_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:34:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:10:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:5:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}}', 'yes'),
(90, 'widget_search', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes'),
(91, 'widget_recent-posts', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes'),
(92, 'widget_recent-comments', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes'),
(93, 'widget_archives', 'a:2:{i:2;a:3:{s:5:"title";s:0:"";s:5:"count";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(94, 'widget_meta', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes'),
(95, 'sidebars_widgets', 'a:3:{s:19:"wp_inactive_widgets";a:0:{}s:18:"orphaned_widgets_1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:13:"array_version";i:3;}', 'yes'),
(98, 'cron', 'a:6:{i:1440487680;a:1:{s:20:"wp_maybe_auto_update";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1440491360;a:1:{s:30:"wp_scheduled_auto_draft_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1440511680;a:3:{s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1440555236;a:1:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}s:20:"wp_batch_split_terms";a:7:{i:1440483633;a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:2:{s:8:"schedule";b:0;s:4:"args";a:0:{}}}i:1440483635;a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:2:{s:8:"schedule";b:0;s:4:"args";a:0:{}}}i:1440483640;a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:2:{s:8:"schedule";b:0;s:4:"args";a:0:{}}}i:1440483650;a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:2:{s:8:"schedule";b:0;s:4:"args";a:0:{}}}i:1440483656;a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:2:{s:8:"schedule";b:0;s:4:"args";a:0:{}}}i:1440483657;a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:2:{s:8:"schedule";b:0;s:4:"args";a:0:{}}}i:1440483696;a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:2:{s:8:"schedule";b:0;s:4:"args";a:0:{}}}}s:7:"version";i:2;}', 'yes'),
(108, '_transient_random_seed', 'eabe754ecec3a6cecfe150fe57edd20a', 'yes'),
(129, 'recently_activated', 'a:4:{s:62:"WordPress-Plugin-Template-master/wordpress-plugin-template.php";i:1440397402;s:35:"jobs-management/jobs_management.php";i:1440130916;s:27:"jobs-widget/jobs_widget.php";i:1440064350;s:13:"jobs/jobs.php";i:1440062971;}', 'yes'),
(131, 'acf_version', '4.4.3', 'yes'),
(132, 'widget_calendar', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(133, 'widget_nav_menu', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(134, 'widget_pages', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(136, 'widget_tag_cloud', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(139, '_transient_twentyfifteen_categories', '1', 'yes'),
(141, 'current_theme', 'August 2015', 'yes'),
(142, 'theme_mods_august2015', 'a:3:{i:0;b:0;s:9:"top_image";s:62:"http://evarecruit.localhost/wp-content/uploads/2015/08/bg1.jpg";s:8:"top_text";s:14:"this is sample";}', 'yes'),
(143, 'theme_switched', '', 'yes'),
(144, 'tadv_settings', 'a:6:{s:7:"options";s:15:"menubar,advlist";s:9:"toolbar_1";s:117:"bold,italic,blockquote,bullist,numlist,alignleft,aligncenter,alignright,link,unlink,table,fullscreen,undo,redo,wp_adv";s:9:"toolbar_2";s:121:"formatselect,alignjustify,strikethrough,outdent,indent,pastetext,removeformat,charmap,wp_more,emoticons,forecolor,wp_help";s:9:"toolbar_3";s:0:"";s:9:"toolbar_4";s:0:"";s:7:"plugins";s:107:"anchor,code,insertdatetime,nonbreaking,print,searchreplace,table,visualblocks,visualchars,emoticons,advlist";}', 'yes'),
(145, 'tadv_admin_settings', 'a:1:{s:7:"options";a:0:{}}', 'yes'),
(146, 'tadv_version', '4000', 'yes'),
(193, 'theme_mods_twentyfourteen', 'a:2:{i:0;b:0;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1439432907;s:4:"data";a:4:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:9:"sidebar-2";N;s:9:"sidebar-3";N;}}}', 'yes'),
(194, 'widget_widget_twentyfourteen_ephemera', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(196, '_transient_twentyfourteen_category_count', '1', 'yes'),
(201, 'theme_mods_twentyfifteen', 'a:1:{s:16:"sidebars_widgets";a:2:{s:4:"time";i:1439434204;s:4:"data";a:2:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}}}}', 'yes'),
(309, 'widget_jobs-widget', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(319, 'DevloungePluginSeriesAdminOptions', 'a:4:{s:11:"show_header";s:4:"true";s:11:"add_content";s:4:"true";s:14:"comment_author";s:4:"true";s:7:"content";s:0:"";}', 'yes'),
(350, 'job-position_children', 'a:0:{}', 'yes'),
(351, 'job-location_children', 'a:0:{}', 'yes'),
(379, '_transient_timeout_plugin_slugs', '1440570124', 'no'),
(380, '_transient_plugin_slugs', 'a:11:{i:0;s:30:"advanced-custom-fields/acf.php";i:1;s:29:"acf-repeater/acf-repeater.php";i:2;s:19:"akismet/akismet.php";i:3;s:45:"taxonomy-terms-order/taxonomy-terms-order.php";i:4;s:43:"custom-post-type-ui/custom-post-type-ui.php";i:5;s:9:"hello.php";i:6;s:35:"jobs-management/jobs_management.php";i:7;s:37:"post-types-order/post-types-order.php";i:8;s:37:"tinymce-advanced/tinymce-advanced.php";i:9;s:27:"wp-pagenavi/wp-pagenavi.php";i:10;s:41:"wp-multibyte-patch/wp-multibyte-patch.php";}', 'no'),
(383, 'widget_wpb_widget', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(384, 'wordpress_plugin_template_version', '1.0.0', 'yes'),
(406, '_site_transient_update_themes', 'O:8:"stdClass":4:{s:12:"last_checked";i:1440483611;s:7:"checked";a:4:{s:10:"august2015";s:3:"1.0";s:13:"twentyfifteen";s:3:"1.2";s:14:"twentyfourteen";s:3:"1.4";s:14:"twentythirteen";s:3:"1.5";}s:8:"response";a:3:{s:13:"twentyfifteen";a:4:{s:5:"theme";s:13:"twentyfifteen";s:11:"new_version";s:3:"1.3";s:3:"url";s:43:"https://wordpress.org/themes/twentyfifteen/";s:7:"package";s:59:"https://downloads.wordpress.org/theme/twentyfifteen.1.3.zip";}s:14:"twentyfourteen";a:4:{s:5:"theme";s:14:"twentyfourteen";s:11:"new_version";s:3:"1.5";s:3:"url";s:44:"https://wordpress.org/themes/twentyfourteen/";s:7:"package";s:60:"https://downloads.wordpress.org/theme/twentyfourteen.1.5.zip";}s:14:"twentythirteen";a:4:{s:5:"theme";s:14:"twentythirteen";s:11:"new_version";s:3:"1.6";s:3:"url";s:44:"https://wordpress.org/themes/twentythirteen/";s:7:"package";s:60:"https://downloads.wordpress.org/theme/twentythirteen.1.6.zip";}}s:12:"translations";a:0:{}}', 'yes'),
(408, '_site_transient_timeout_theme_roots', '1440485337', 'yes'),
(409, '_site_transient_theme_roots', 'a:4:{s:10:"august2015";s:7:"/themes";s:13:"twentyfifteen";s:7:"/themes";s:14:"twentyfourteen";s:7:"/themes";s:14:"twentythirteen";s:7:"/themes";}', 'yes'),
(410, 'finished_splitting_shared_terms', '1', 'yes'),
(411, 'db_upgraded', '', 'yes'),
(413, '_site_transient_update_core', 'O:8:"stdClass":4:{s:7:"updates";a:1:{i:0;O:8:"stdClass":10:{s:8:"response";s:6:"latest";s:8:"download";s:57:"https://downloads.wordpress.org/release/wordpress-4.3.zip";s:6:"locale";s:5:"en_US";s:8:"packages";O:8:"stdClass":5:{s:4:"full";s:57:"https://downloads.wordpress.org/release/wordpress-4.3.zip";s:10:"no_content";s:68:"https://downloads.wordpress.org/release/wordpress-4.3-no-content.zip";s:11:"new_bundled";s:69:"https://downloads.wordpress.org/release/wordpress-4.3-new-bundled.zip";s:7:"partial";b:0;s:8:"rollback";b:0;}s:7:"current";s:3:"4.3";s:7:"version";s:3:"4.3";s:11:"php_version";s:5:"5.2.4";s:13:"mysql_version";s:3:"5.0";s:11:"new_bundled";s:3:"4.1";s:15:"partial_version";s:0:"";}}s:12:"last_checked";i:1440483573;s:15:"version_checked";s:3:"4.3";s:12:"translations";a:0:{}}', 'yes'),
(414, 'rewrite_rules', 'a:153:{s:6:"job/?$";s:23:"index.php?post_type=job";s:36:"job/feed/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?post_type=job&feed=$matches[1]";s:31:"job/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?post_type=job&feed=$matches[1]";s:23:"job/page/([0-9]{1,})/?$";s:41:"index.php?post_type=job&paged=$matches[1]";s:10:"service/?$";s:27:"index.php?post_type=service";s:40:"service/feed/(feed|rdf|rss|rss2|atom)/?$";s:44:"index.php?post_type=service&feed=$matches[1]";s:35:"service/(feed|rdf|rss|rss2|atom)/?$";s:44:"index.php?post_type=service&feed=$matches[1]";s:27:"service/page/([0-9]{1,})/?$";s:45:"index.php?post_type=service&paged=$matches[1]";s:47:"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:42:"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:35:"category/(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&paged=$matches[2]";s:17:"category/(.+?)/?$";s:35:"index.php?category_name=$matches[1]";s:44:"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:39:"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:32:"tag/([^/]+)/page/?([0-9]{1,})/?$";s:43:"index.php?tag=$matches[1]&paged=$matches[2]";s:14:"tag/([^/]+)/?$";s:25:"index.php?tag=$matches[1]";s:45:"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:40:"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:33:"type/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?post_format=$matches[1]&paged=$matches[2]";s:15:"type/([^/]+)/?$";s:33:"index.php?post_format=$matches[1]";s:31:"job/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:41:"job/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:61:"job/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:56:"job/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:56:"job/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:24:"job/([^/]+)/trackback/?$";s:30:"index.php?job=$matches[1]&tb=1";s:44:"job/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?job=$matches[1]&feed=$matches[2]";s:39:"job/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?job=$matches[1]&feed=$matches[2]";s:32:"job/([^/]+)/page/?([0-9]{1,})/?$";s:43:"index.php?job=$matches[1]&paged=$matches[2]";s:39:"job/([^/]+)/comment-page-([0-9]{1,})/?$";s:43:"index.php?job=$matches[1]&cpage=$matches[2]";s:24:"job/([^/]+)(/[0-9]+)?/?$";s:42:"index.php?job=$matches[1]&page=$matches[2]";s:20:"job/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:30:"job/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:50:"job/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:45:"job/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:45:"job/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:53:"job-location/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:51:"index.php?job-location=$matches[1]&feed=$matches[2]";s:48:"job-location/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:51:"index.php?job-location=$matches[1]&feed=$matches[2]";s:41:"job-location/([^/]+)/page/?([0-9]{1,})/?$";s:52:"index.php?job-location=$matches[1]&paged=$matches[2]";s:23:"job-location/([^/]+)/?$";s:34:"index.php?job-location=$matches[1]";s:53:"job-position/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:51:"index.php?job-position=$matches[1]&feed=$matches[2]";s:48:"job-position/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:51:"index.php?job-position=$matches[1]&feed=$matches[2]";s:41:"job-position/([^/]+)/page/?([0-9]{1,})/?$";s:52:"index.php?job-position=$matches[1]&paged=$matches[2]";s:23:"job-position/([^/]+)/?$";s:34:"index.php?job-position=$matches[1]";s:35:"service/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:45:"service/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:65:"service/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:60:"service/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:60:"service/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:28:"service/([^/]+)/trackback/?$";s:34:"index.php?service=$matches[1]&tb=1";s:48:"service/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:46:"index.php?service=$matches[1]&feed=$matches[2]";s:43:"service/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:46:"index.php?service=$matches[1]&feed=$matches[2]";s:36:"service/([^/]+)/page/?([0-9]{1,})/?$";s:47:"index.php?service=$matches[1]&paged=$matches[2]";s:43:"service/([^/]+)/comment-page-([0-9]{1,})/?$";s:47:"index.php?service=$matches[1]&cpage=$matches[2]";s:28:"service/([^/]+)(/[0-9]+)?/?$";s:46:"index.php?service=$matches[1]&page=$matches[2]";s:24:"service/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:34:"service/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:54:"service/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:49:"service/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:49:"service/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:44:"work-environment/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:54:"work-environment/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:74:"work-environment/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:69:"work-environment/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:69:"work-environment/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:37:"work-environment/([^/]+)/trackback/?$";s:43:"index.php?work-environment=$matches[1]&tb=1";s:45:"work-environment/([^/]+)/page/?([0-9]{1,})/?$";s:56:"index.php?work-environment=$matches[1]&paged=$matches[2]";s:52:"work-environment/([^/]+)/comment-page-([0-9]{1,})/?$";s:56:"index.php?work-environment=$matches[1]&cpage=$matches[2]";s:37:"work-environment/([^/]+)(/[0-9]+)?/?$";s:55:"index.php?work-environment=$matches[1]&page=$matches[2]";s:33:"work-environment/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:43:"work-environment/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:63:"work-environment/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:58:"work-environment/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:58:"work-environment/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:42:"stay-connected/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:52:"stay-connected/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:72:"stay-connected/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:67:"stay-connected/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:67:"stay-connected/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:35:"stay-connected/([^/]+)/trackback/?$";s:41:"index.php?stay-connected=$matches[1]&tb=1";s:43:"stay-connected/([^/]+)/page/?([0-9]{1,})/?$";s:54:"index.php?stay-connected=$matches[1]&paged=$matches[2]";s:50:"stay-connected/([^/]+)/comment-page-([0-9]{1,})/?$";s:54:"index.php?stay-connected=$matches[1]&cpage=$matches[2]";s:35:"stay-connected/([^/]+)(/[0-9]+)?/?$";s:53:"index.php?stay-connected=$matches[1]&page=$matches[2]";s:31:"stay-connected/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:41:"stay-connected/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:61:"stay-connected/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:56:"stay-connected/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:56:"stay-connected/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:61:"cat-work-environment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:59:"index.php?cat-work-environment=$matches[1]&feed=$matches[2]";s:56:"cat-work-environment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:59:"index.php?cat-work-environment=$matches[1]&feed=$matches[2]";s:49:"cat-work-environment/([^/]+)/page/?([0-9]{1,})/?$";s:60:"index.php?cat-work-environment=$matches[1]&paged=$matches[2]";s:31:"cat-work-environment/([^/]+)/?$";s:42:"index.php?cat-work-environment=$matches[1]";s:12:"robots\\.txt$";s:18:"index.php?robots=1";s:48:".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$";s:18:"index.php?feed=old";s:20:".*wp-app\\.php(/.*)?$";s:19:"index.php?error=403";s:18:".*wp-register.php$";s:23:"index.php?register=true";s:32:"feed/(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:27:"(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:20:"page/?([0-9]{1,})/?$";s:28:"index.php?&paged=$matches[1]";s:41:"comments/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:36:"comments/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:44:"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:39:"search/(.+)/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:32:"search/(.+)/page/?([0-9]{1,})/?$";s:41:"index.php?s=$matches[1]&paged=$matches[2]";s:14:"search/(.+)/?$";s:23:"index.php?s=$matches[1]";s:47:"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:42:"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:35:"author/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?author_name=$matches[1]&paged=$matches[2]";s:17:"author/([^/]+)/?$";s:33:"index.php?author_name=$matches[1]";s:69:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]";s:39:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$";s:63:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]";s:56:"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:51:"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:44:"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]";s:26:"([0-9]{4})/([0-9]{1,2})/?$";s:47:"index.php?year=$matches[1]&monthnum=$matches[2]";s:43:"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:38:"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:31:"([0-9]{4})/page/?([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&paged=$matches[2]";s:13:"([0-9]{4})/?$";s:26:"index.php?year=$matches[1]";s:27:".?.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:".?.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:20:"(.?.+?)/trackback/?$";s:35:"index.php?pagename=$matches[1]&tb=1";s:40:"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:35:"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:28:"(.?.+?)/page/?([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&paged=$matches[2]";s:35:"(.?.+?)/comment-page-([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&cpage=$matches[2]";s:20:"(.?.+?)(/[0-9]+)?/?$";s:47:"index.php?pagename=$matches[1]&page=$matches[2]";s:31:".+?/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:41:".+?/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:61:".+?/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:56:".+?/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:56:".+?/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:26:"(.+?)/([^/]+)/trackback/?$";s:57:"index.php?category_name=$matches[1]&name=$matches[2]&tb=1";s:46:"(.+?)/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:69:"index.php?category_name=$matches[1]&name=$matches[2]&feed=$matches[3]";s:41:"(.+?)/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:69:"index.php?category_name=$matches[1]&name=$matches[2]&feed=$matches[3]";s:34:"(.+?)/([^/]+)/page/?([0-9]{1,})/?$";s:70:"index.php?category_name=$matches[1]&name=$matches[2]&paged=$matches[3]";s:41:"(.+?)/([^/]+)/comment-page-([0-9]{1,})/?$";s:70:"index.php?category_name=$matches[1]&name=$matches[2]&cpage=$matches[3]";s:26:"(.+?)/([^/]+)(/[0-9]+)?/?$";s:69:"index.php?category_name=$matches[1]&name=$matches[2]&page=$matches[3]";s:20:".+?/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:30:".+?/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:50:".+?/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:45:".+?/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:45:".+?/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:38:"(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:33:"(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:26:"(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&paged=$matches[2]";s:33:"(.+?)/comment-page-([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&cpage=$matches[2]";s:8:"(.+?)/?$";s:35:"index.php?category_name=$matches[1]";}', 'yes'),
(415, 'can_compress_scripts', '0', 'yes'),
(418, '_site_transient_update_plugins', 'O:8:"stdClass":5:{s:12:"last_checked";i:1440483637;s:7:"checked";a:13:{s:30:"advanced-custom-fields/acf.php";s:5:"4.4.3";s:29:"acf-repeater/acf-repeater.php";s:5:"1.1.1";s:19:"akismet/akismet.php";s:5:"3.1.3";s:45:"taxonomy-terms-order/taxonomy-terms-order.php";s:7:"1.4.6.1";s:43:"custom-post-type-ui/custom-post-type-ui.php";s:5:"1.1.2";s:9:"hello.php";s:3:"1.6";s:35:"jobs-management/jobs_management.php";s:3:"1.0";s:27:"jobs-widget/jobs_widget.php";s:5:"1.0.0";s:37:"post-types-order/post-types-order.php";s:7:"1.8.4.1";s:37:"tinymce-advanced/tinymce-advanced.php";s:7:"4.2.3.1";s:62:"WordPress-Plugin-Template-master/wordpress-plugin-template.php";s:3:"1.0";s:27:"wp-pagenavi/wp-pagenavi.php";s:4:"2.88";s:41:"wp-multibyte-patch/wp-multibyte-patch.php";s:3:"2.4";}s:8:"response";a:0:{}s:12:"translations";a:0:{}s:9:"no_update";a:9:{s:30:"advanced-custom-fields/acf.php";O:8:"stdClass":6:{s:2:"id";s:5:"21367";s:4:"slug";s:22:"advanced-custom-fields";s:6:"plugin";s:30:"advanced-custom-fields/acf.php";s:11:"new_version";s:5:"4.4.3";s:3:"url";s:53:"https://wordpress.org/plugins/advanced-custom-fields/";s:7:"package";s:65:"https://downloads.wordpress.org/plugin/advanced-custom-fields.zip";}s:19:"akismet/akismet.php";O:8:"stdClass":6:{s:2:"id";s:2:"15";s:4:"slug";s:7:"akismet";s:6:"plugin";s:19:"akismet/akismet.php";s:11:"new_version";s:5:"3.1.3";s:3:"url";s:38:"https://wordpress.org/plugins/akismet/";s:7:"package";s:56:"https://downloads.wordpress.org/plugin/akismet.3.1.3.zip";}s:45:"taxonomy-terms-order/taxonomy-terms-order.php";O:8:"stdClass":6:{s:2:"id";s:5:"23884";s:4:"slug";s:20:"taxonomy-terms-order";s:6:"plugin";s:45:"taxonomy-terms-order/taxonomy-terms-order.php";s:11:"new_version";s:7:"1.4.6.1";s:3:"url";s:51:"https://wordpress.org/plugins/taxonomy-terms-order/";s:7:"package";s:63:"https://downloads.wordpress.org/plugin/taxonomy-terms-order.zip";}s:43:"custom-post-type-ui/custom-post-type-ui.php";O:8:"stdClass":7:{s:2:"id";s:5:"13183";s:4:"slug";s:19:"custom-post-type-ui";s:6:"plugin";s:43:"custom-post-type-ui/custom-post-type-ui.php";s:11:"new_version";s:5:"1.1.2";s:3:"url";s:50:"https://wordpress.org/plugins/custom-post-type-ui/";s:7:"package";s:68:"https://downloads.wordpress.org/plugin/custom-post-type-ui.1.1.2.zip";s:14:"upgrade_notice";s:284:"Change export value to plural label for taxonomies.\nProperly select a post type or taxonomy after deleting an existing value.\nUpdated screenshots\nAdded target=&quot;_blank&quot; attribute to one of the inline help links for Menu position. Thanks @JulieKuehl\nFixed potential XSS issue.";}s:9:"hello.php";O:8:"stdClass":6:{s:2:"id";s:4:"3564";s:4:"slug";s:11:"hello-dolly";s:6:"plugin";s:9:"hello.php";s:11:"new_version";s:3:"1.6";s:3:"url";s:42:"https://wordpress.org/plugins/hello-dolly/";s:7:"package";s:58:"https://downloads.wordpress.org/plugin/hello-dolly.1.6.zip";}s:37:"post-types-order/post-types-order.php";O:8:"stdClass":6:{s:2:"id";s:5:"17292";s:4:"slug";s:16:"post-types-order";s:6:"plugin";s:37:"post-types-order/post-types-order.php";s:11:"new_version";s:7:"1.8.4.1";s:3:"url";s:47:"https://wordpress.org/plugins/post-types-order/";s:7:"package";s:59:"https://downloads.wordpress.org/plugin/post-types-order.zip";}s:37:"tinymce-advanced/tinymce-advanced.php";O:8:"stdClass":6:{s:2:"id";s:3:"731";s:4:"slug";s:16:"tinymce-advanced";s:6:"plugin";s:37:"tinymce-advanced/tinymce-advanced.php";s:11:"new_version";s:7:"4.2.3.1";s:3:"url";s:47:"https://wordpress.org/plugins/tinymce-advanced/";s:7:"package";s:67:"https://downloads.wordpress.org/plugin/tinymce-advanced.4.2.3.1.zip";}s:27:"wp-pagenavi/wp-pagenavi.php";O:8:"stdClass":6:{s:2:"id";s:3:"363";s:4:"slug";s:11:"wp-pagenavi";s:6:"plugin";s:27:"wp-pagenavi/wp-pagenavi.php";s:11:"new_version";s:4:"2.88";s:3:"url";s:42:"https://wordpress.org/plugins/wp-pagenavi/";s:7:"package";s:59:"https://downloads.wordpress.org/plugin/wp-pagenavi.2.88.zip";}s:41:"wp-multibyte-patch/wp-multibyte-patch.php";O:8:"stdClass":6:{s:2:"id";s:5:"24017";s:4:"slug";s:18:"wp-multibyte-patch";s:6:"plugin";s:41:"wp-multibyte-patch/wp-multibyte-patch.php";s:11:"new_version";s:3:"2.4";s:3:"url";s:49:"https://wordpress.org/plugins/wp-multibyte-patch/";s:7:"package";s:65:"https://downloads.wordpress.org/plugin/wp-multibyte-patch.2.4.zip";}}}', 'yes'),
(421, 'pagenavi_options', 'a:15:{s:10:"pages_text";s:36:"Page %CURRENT_PAGE% of %TOTAL_PAGES%";s:12:"current_text";s:13:"%PAGE_NUMBER%";s:9:"page_text";s:13:"%PAGE_NUMBER%";s:10:"first_text";s:13:"&laquo; First";s:9:"last_text";s:12:"Last &raquo;";s:9:"prev_text";s:7:"&laquo;";s:9:"next_text";s:7:"&raquo;";s:12:"dotleft_text";s:3:"...";s:13:"dotright_text";s:3:"...";s:9:"num_pages";i:5;s:23:"num_larger_page_numbers";i:3;s:28:"larger_page_numbers_multiple";i:10;s:11:"always_show";b:0;s:16:"use_pagenavi_css";b:1;s:5:"style";i:1;}', 'yes'),
(422, 'cpto_options', 'a:5:{s:23:"show_reorder_interfaces";a:0:{}s:8:"autosort";i:1;s:9:"adminsort";i:1;s:10:"capability";s:15:"install_plugins";s:21:"navigation_sort_apply";i:1;}', 'yes'),
(423, 'tto_options', 'a:3:{s:8:"autosort";s:1:"1";s:9:"adminsort";s:1:"1";s:10:"capability";s:15:"install_plugins";}', 'yes');

-- --------------------------------------------------------

--
-- Table structure for table `wp_postmeta`
--

CREATE TABLE IF NOT EXISTS `wp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=107 ;

--
-- Dumping data for table `wp_postmeta`
--

INSERT INTO `wp_postmeta` (`meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1, 2, '_wp_page_template', 'default'),
(2, 4, '_wp_attached_file', '2015/08/bg1.jpg'),
(3, 4, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1600;s:6:"height";i:550;s:4:"file";s:15:"2015/08/bg1.jpg";s:5:"sizes";a:18:{s:9:"thumbnail";a:4:{s:4:"file";s:15:"bg1-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:15:"bg1-300x103.jpg";s:5:"width";i:300;s:6:"height";i:103;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:16:"bg1-1024x352.jpg";s:5:"width";i:1024;s:6:"height";i:352;s:9:"mime-type";s:10:"image/jpeg";}s:6:"img_re";a:4:{s:4:"file";s:15:"bg1-300x260.jpg";s:5:"width";i:300;s:6:"height";i:260;s:9:"mime-type";s:10:"image/jpeg";}s:11:"recommend01";a:4:{s:4:"file";s:15:"bg1-265x187.jpg";s:5:"width";i:265;s:6:"height";i:187;s:9:"mime-type";s:10:"image/jpeg";}s:11:"recommend02";a:4:{s:4:"file";s:14:"bg1-198x68.jpg";s:5:"width";i:198;s:6:"height";i:68;s:9:"mime-type";s:10:"image/jpeg";}s:11:"recommend03";a:4:{s:4:"file";s:14:"bg1-150x52.jpg";s:5:"width";i:150;s:6:"height";i:52;s:9:"mime-type";s:10:"image/jpeg";}s:11:"recommend04";a:4:{s:4:"file";s:13:"bg1-75x26.jpg";s:5:"width";i:75;s:6:"height";i:26;s:9:"mime-type";s:10:"image/jpeg";}s:11:"recommend05";a:4:{s:4:"file";s:13:"bg1-58x20.jpg";s:5:"width";i:58;s:6:"height";i:20;s:9:"mime-type";s:10:"image/jpeg";}s:11:"recommend06";a:4:{s:4:"file";s:14:"bg1-265x91.jpg";s:5:"width";i:265;s:6:"height";i:91;s:9:"mime-type";s:10:"image/jpeg";}s:9:"gallery01";a:4:{s:4:"file";s:15:"bg1-600x206.jpg";s:5:"width";i:600;s:6:"height";i:206;s:9:"mime-type";s:10:"image/jpeg";}s:9:"gallery02";a:4:{s:4:"file";s:15:"bg1-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}s:8:"circle01";a:4:{s:4:"file";s:15:"bg1-264x184.jpg";s:5:"width";i:264;s:6:"height";i:184;s:9:"mime-type";s:10:"image/jpeg";}s:8:"result01";a:4:{s:4:"file";s:15:"bg1-325x112.jpg";s:5:"width";i:325;s:6:"height";i:112;s:9:"mime-type";s:10:"image/jpeg";}s:7:"staff01";a:4:{s:4:"file";s:15:"bg1-162x162.jpg";s:5:"width";i:162;s:6:"height";i:162;s:9:"mime-type";s:10:"image/jpeg";}s:7:"staff02";a:4:{s:4:"file";s:15:"bg1-124x124.jpg";s:5:"width";i:124;s:6:"height";i:124;s:9:"mime-type";s:10:"image/jpeg";}s:7:"staff03";a:4:{s:4:"file";s:15:"bg1-224x328.jpg";s:5:"width";i:224;s:6:"height";i:328;s:9:"mime-type";s:10:"image/jpeg";}s:7:"staff04";a:4:{s:4:"file";s:15:"bg1-101x101.jpg";s:5:"width";i:101;s:6:"height";i:101;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}'),
(4, 2, '_edit_lock', '1440055326:1'),
(5, 4, '_wp_attachment_custom_header_last_used_august2015', '1439433427'),
(6, 4, '_wp_attachment_is_custom_header', 'august2015'),
(7, 12, '_edit_last', '1'),
(8, 12, '_edit_lock', '1440041062:1'),
(9, 12, 'main_locations_0_main_location', '4F Saigon Finance Center'),
(10, 12, '_main_locations_0_main_location', 'field_55cb1ac128142'),
(11, 12, 'main_locations_0_address', '9 Dinh Tien Hoang Street, District 1, HCMC'),
(12, 12, '_main_locations_0_address', 'field_55cb1ad028143'),
(13, 12, 'main_locations_0_lat', '10.7894162'),
(14, 12, '_main_locations_0_lat', 'field_55d2b9ae1e9dc'),
(15, 12, 'main_locations_0_lng', '106.69864699999994'),
(16, 12, '_main_locations_0_lng', 'field_55d2b9d41e9dd'),
(17, 12, 'main_locations_1_main_location', '14 GOLDEN TOWER'),
(18, 12, '_main_locations_1_main_location', 'field_55cb1ac128142'),
(19, 12, 'main_locations_1_address', '6 Nguyen Thi Minh Khai Street, District 1, HCMC'),
(20, 12, '_main_locations_1_address', 'field_55cb1ad028143'),
(21, 12, 'main_locations_1_lat', '10.788701894342939'),
(22, 12, '_main_locations_1_lat', 'field_55d2b9ae1e9dc'),
(23, 12, 'main_locations_1_lng', '106.7035056690338'),
(24, 12, '_main_locations_1_lng', 'field_55d2b9d41e9dd'),
(25, 12, 'main_locations', '2'),
(26, 12, '_main_locations', 'field_55cb1a6e28141'),
(27, 13, '_edit_last', '1'),
(28, 13, '_edit_lock', '1439948927:1'),
(29, 13, 'main_locations_0_main_location', '9F Viet A Building'),
(30, 13, '_main_locations_0_main_location', 'field_55cb1ac128142'),
(31, 13, 'main_locations_0_address', 'Duy Tan Street, Cau Giay District, Ha Noi'),
(32, 13, '_main_locations_0_address', 'field_55cb1ad028143'),
(33, 13, 'main_locations_0_lat', '21.0314059'),
(34, 13, '_main_locations_0_lat', 'field_55d2b9ae1e9dc'),
(35, 13, 'main_locations_0_lng', '105.78001530000006'),
(36, 13, '_main_locations_0_lng', 'field_55d2b9d41e9dd'),
(37, 13, 'main_locations', '1'),
(38, 13, '_main_locations', 'field_55cb1a6e28141'),
(39, 14, '_edit_last', '1'),
(40, 14, '_edit_lock', '1439948939:1'),
(41, 14, 'main_locations_0_main_location', 'Da Nang Software Park Building'),
(42, 14, '_main_locations_0_main_location', 'field_55cb1ac128142'),
(43, 14, 'main_locations_0_address', '02 Quang Trung St., Hai Chau District, Da Nang, Viet Nam'),
(44, 14, '_main_locations_0_address', 'field_55cb1ad028143'),
(45, 14, 'main_locations_0_lat', '16.0472002'),
(46, 14, '_main_locations_0_lat', 'field_55d2b9ae1e9dc'),
(47, 14, 'main_locations_0_lng', '108.21995879999997'),
(48, 14, '_main_locations_0_lng', 'field_55d2b9d41e9dd'),
(49, 14, 'main_locations', '1'),
(50, 14, '_main_locations', 'field_55cb1a6e28141'),
(51, 12, 'z_lat', '10.7894162'),
(52, 12, '_z_lat', 'field_55d3e047adf77'),
(53, 12, 'z_lng', '106.69864699999994'),
(54, 12, '_z_lng', 'field_55d3e05fadf78'),
(55, 13, 'z_lat', '21.0314059'),
(56, 13, '_z_lat', 'field_55d3e047adf77'),
(57, 13, 'z_lng', '105.78001530000006'),
(58, 13, '_z_lng', 'field_55d3e05fadf78'),
(59, 14, 'z_lat', '16.0472002'),
(60, 14, '_z_lat', 'field_55d3e047adf77'),
(61, 14, 'z_lng', '108.21995879999997'),
(62, 14, '_z_lng', 'field_55d3e05fadf78'),
(63, 25, '_edit_last', '1'),
(64, 25, '_edit_lock', '1440064994:1'),
(65, 25, '_wp_page_template', 'default'),
(66, 2, '_wp_trash_meta_status', 'publish'),
(67, 2, '_wp_trash_meta_time', '1440064035'),
(68, 28, '_edit_last', '1'),
(69, 28, '_edit_lock', '1440064138:1'),
(70, 29, '_edit_last', '1'),
(71, 29, '_wp_page_template', 'templates/jobs.php'),
(72, 29, '_edit_lock', '1440064961:1'),
(73, 28, '_wp_page_template', 'default'),
(74, 33, '_edit_last', '1'),
(75, 33, 'position', '4'),
(76, 33, '_position', 'field_55cb0d1a13787'),
(77, 33, 'work_level', 'Member'),
(78, 33, '_work_level', 'field_55cb0d7913788'),
(79, 33, 'salary', '1500$'),
(80, 33, '_salary', 'field_55cb0e2713789'),
(81, 33, 'location', '6'),
(82, 33, '_location', 'field_55cb0e611378a'),
(83, 33, 'expire_date', '20152015-09-28'),
(84, 33, '_expire_date', 'field_55cb0e7e1378b'),
(85, 33, 'job_description', '<div>-Be a co-coordinator and project manager to manage the team in order to achieve the projects’ objectives.</div>\r\n<div>-Work in a young and dynamic working environment among Japanese and Vietnamese developers.\r\n<u><strong>Principal Accountabilities:</strong></u>\r\n-Transfer System Requirements including system design, definition, development and operational activities from Japanese to Vietnamese and vice versa to developers\r\n-Effective manage the project by closely communicating with Project team in Japan\r\n-Join the Skype Meeting, Chat Meeting and face to face meeting using Japanese language\r\n-Assist Project Manager and other Bridge SE in processing project.\r\n<u><strong>Benefits:</strong></u>\r\n-Salary package: Competitive and negotiable\r\n-Performance review: 2 times/ year\r\n-Lunch Allowance.\r\n-Applicable for all normal benefits: insurance, 13th salary, annual outing trip, team building activities, Kick off party 01 time/quarter\r\n-Sport activities: Football, swimming, badminton etc. (Company sponsor)\r\n-Training: Language training, soft skills and technical skills training.</div>'),
(86, 33, '_job_description', 'field_55cb0ed21378c'),
(87, 33, 'job_requirement', '<u><strong>+ Education:</strong></u> University degree in Computer Science, Information Technology or equivalent\r\n<u><strong>+ Experience:</strong></u>\r\n-At least 3-year experience in software development and IT field\r\n-At least 3-year experience in development/project management and system design or managerial levels.\r\n<u><strong>+ Skills: </strong></u>\r\n- Be good at Japanese speaking and written skills (2 kyu level)\r\n- Be good at project management and communication skills\r\n- Be good at analytical skills\r\n- Be meticulous with effective follow-up skills\r\n- Has ability to work in a dynamic and fast pace environment\r\n- Be proactive, ambitious, willing to work hard\r\n- Has ability for self-studying/improving and teamwork spirit'),
(88, 33, '_job_requirement', 'field_55cb0ee71378d'),
(89, 33, '_edit_lock', '1440392198:1'),
(90, 33, '_wp_old_slug', '33'),
(91, 33, 'status', 'normal'),
(92, 33, '_status', 'field_55da913d03fc1'),
(93, 40, '_edit_last', '1'),
(94, 40, '_edit_lock', '1440397140:1'),
(95, 40, 'status', 'urgent'),
(96, 40, '_status', 'field_55da913d03fc1'),
(97, 40, 'work_level', 'Member'),
(98, 40, '_work_level', 'field_55cb0d7913788'),
(99, 40, 'salary', '600 - 1200usd'),
(100, 40, '_salary', 'field_55cb0e2713789'),
(101, 40, 'expire_date', '20152015-09-19'),
(102, 40, '_expire_date', 'field_55cb0e7e1378b'),
(103, 40, 'job_description', 'Apply today to join our winning team for:\r\n- Competitive working conditions and wages\r\n- Competitive benefits : Daily lunch, 13th-month salary, Training, Vacation Trip, Team building activities and more.( Sport activities: Football, swimming, badminton etc. (Company sponsor)\r\n- Performance review: 2 times/ year\r\n- Working for a progressive company\r\n- Learning and applying many kinds of language PHP, Java, Mobile Application\r\n- Working in an environment where there is respect for your ideas and where creativity is welcomed'),
(104, 40, '_job_description', 'field_55cb0ed21378c'),
(105, 40, 'job_requirement', '<u><strong>+ Education:</strong></u> University degree in Computer Science, Information Technology or equivalent\r\n\r\n<u><strong>+ Experience:</strong></u>\r\n- At least 2 years of developing experience\r\n- Advanced in LAMP, HTML/CSS/JavaScript\r\n- Experience in Phalcon, Cake PHP, Codeigniter - CI, Zend or Symfony Framework is a plus\r\n\r\n<u><strong>+ Skills:</strong></u>\r\n- Be able to read and understand English documents is plus\r\n- Good sense of teamwork and high responsibility\r\n- Good communication skill\r\n- Self-motivated, self-disciplined'),
(106, 40, '_job_requirement', 'field_55cb0ee71378d');

-- --------------------------------------------------------

--
-- Table structure for table `wp_posts`
--

CREATE TABLE IF NOT EXISTS `wp_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_title` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_excerpt` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `to_ping` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `pinged` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`(191)),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=41 ;

--
-- Dumping data for table `wp_posts`
--

INSERT INTO `wp_posts` (`ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(1, 1, '2015-08-06 02:07:59', '2015-08-06 02:07:59', 'Welcome to WordPress. This is your first post. Edit or delete it, then start blogging!', 'Hello world!', '', 'publish', 'open', 'open', '', 'hello-world', '', '', '2015-08-06 02:07:59', '2015-08-06 02:07:59', '', 0, 'http://evarecruit.localhost/?p=1', 0, 'post', '', 1),
(2, 1, '2015-08-06 02:07:59', '2015-08-06 02:07:59', 'This is an example page. It''s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:\n\n<blockquote>Hi there! I''m a bike messenger by day, aspiring actor by night, and this is my blog. I live in Los Angeles, have a great dog named Jack, and I like pi&#241;a coladas. (And gettin'' caught in the rain.)</blockquote>\n\n...or something like this:\n\n<blockquote>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</blockquote>\n\nAs a new WordPress user, you should go to <a href="http://evarecruit.localhost/wp-admin/">your dashboard</a> to delete this page and create new pages for your content. Have fun!', 'Sample Page', '', 'trash', 'open', 'open', '', 'sample-page', '', '', '2015-08-20 09:47:15', '2015-08-20 09:47:15', '', 0, 'http://evarecruit.localhost/?page_id=2', 0, 'page', '', 0),
(4, 1, '2015-08-06 02:41:20', '2015-08-06 02:41:20', '', 'bg1', '', 'inherit', 'open', 'open', '', 'bg1', '', '', '2015-08-06 02:41:20', '2015-08-06 02:41:20', '', 0, 'http://evarecruit.localhost/wp-content/uploads/2015/08/bg1.jpg', 0, 'attachment', 'image/jpeg', 0),
(11, 1, '2015-08-18 04:47:34', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2015-08-18 04:47:34', '0000-00-00 00:00:00', '', 0, 'http://evarecruit.localhost/?post_type=stay-connected&p=11', 0, 'stay-connected', '', 0),
(12, 1, '2015-08-18 05:31:41', '2015-08-18 05:31:41', '', 'Hồ Chí Minh', '', 'publish', 'closed', 'closed', '', 'ho-chi-minh', '', '', '2015-08-19 01:50:42', '2015-08-19 01:50:42', '', 0, 'http://evarecruit.localhost/?post_type=stay-connected&#038;p=12', 0, 'stay-connected', '', 0),
(13, 1, '2015-08-18 05:39:49', '2015-08-18 05:39:49', '', 'Hà Nội', '', 'publish', 'closed', 'closed', '', 'ha-noi', '', '', '2015-08-19 01:51:10', '2015-08-19 01:51:10', '', 0, 'http://evarecruit.localhost/?post_type=stay-connected&#038;p=13', 0, 'stay-connected', '', 0),
(14, 1, '2015-08-18 05:42:44', '2015-08-18 05:42:44', '', 'Đà Nẵng', '', 'publish', 'closed', 'closed', '', 'da-nang', '', '', '2015-08-19 01:51:21', '2015-08-19 01:51:21', '', 0, 'http://evarecruit.localhost/?post_type=stay-connected&#038;p=14', 0, 'stay-connected', '', 0),
(15, 1, '2015-08-19 06:32:34', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2015-08-19 06:32:34', '0000-00-00 00:00:00', '', 0, 'http://evarecruit.localhost/?post_type=job&p=15', 0, 'job', '', 0),
(16, 1, '2015-08-19 08:30:31', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2015-08-19 08:30:31', '0000-00-00 00:00:00', '', 0, 'http://evarecruit.localhost/?page_id=16', 0, 'page', '', 0),
(17, 1, '2015-08-19 08:31:51', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2015-08-19 08:31:51', '0000-00-00 00:00:00', '', 0, 'http://evarecruit.localhost/?post_type=job&p=17', 0, 'job', '', 0),
(18, 1, '2015-08-19 09:33:35', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2015-08-19 09:33:35', '0000-00-00 00:00:00', '', 0, 'http://evarecruit.localhost/?page_id=18', 0, 'page', '', 0),
(19, 1, '2015-08-20 06:05:18', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2015-08-20 06:05:18', '0000-00-00 00:00:00', '', 0, 'http://evarecruit.localhost/?page_id=19', 0, 'page', '', 0),
(20, 1, '2015-08-20 06:05:26', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2015-08-20 06:05:26', '0000-00-00 00:00:00', '', 0, 'http://evarecruit.localhost/?page_id=20', 0, 'page', '', 0),
(21, 1, '2015-08-20 06:05:32', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2015-08-20 06:05:32', '0000-00-00 00:00:00', '', 0, 'http://evarecruit.localhost/?page_id=21', 0, 'page', '', 0),
(22, 1, '2015-08-20 06:24:28', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2015-08-20 06:24:28', '0000-00-00 00:00:00', '', 0, 'http://evarecruit.localhost/?page_id=22', 0, 'page', '', 0),
(23, 1, '2015-08-20 06:25:00', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2015-08-20 06:25:00', '0000-00-00 00:00:00', '', 0, 'http://evarecruit.localhost/?page_id=23', 0, 'page', '', 0),
(24, 1, '2015-08-20 06:39:27', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2015-08-20 06:39:27', '0000-00-00 00:00:00', '', 0, 'http://evarecruit.localhost/?page_id=24', 0, 'page', '', 0),
(25, 1, '2015-08-20 07:25:18', '2015-08-20 07:25:18', '', 'Services', '', 'publish', 'open', 'open', '', 'services', '', '', '2015-08-20 10:05:27', '2015-08-20 10:05:27', '', 0, 'http://evarecruit.localhost/?page_id=25', 0, 'page', '', 0),
(26, 1, '2015-08-20 07:25:18', '2015-08-20 07:25:18', '', 'services', '', 'inherit', 'open', 'open', '', '25-revision-v1', '', '', '2015-08-20 07:25:18', '2015-08-20 07:25:18', '', 25, 'http://evarecruit.localhost/uncategorized/25-revision-v1', 0, 'revision', '', 0),
(27, 1, '2015-08-20 09:47:15', '2015-08-20 09:47:15', 'This is an example page. It''s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:\n\n<blockquote>Hi there! I''m a bike messenger by day, aspiring actor by night, and this is my blog. I live in Los Angeles, have a great dog named Jack, and I like pi&#241;a coladas. (And gettin'' caught in the rain.)</blockquote>\n\n...or something like this:\n\n<blockquote>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</blockquote>\n\nAs a new WordPress user, you should go to <a href="http://evarecruit.localhost/wp-admin/">your dashboard</a> to delete this page and create new pages for your content. Have fun!', 'Sample Page', '', 'inherit', 'open', 'open', '', '2-revision-v1', '', '', '2015-08-20 09:47:15', '2015-08-20 09:47:15', '', 2, 'http://evarecruit.localhost/uncategorized/2-revision-v1', 0, 'revision', '', 0),
(28, 1, '2015-08-20 09:51:10', '2015-08-20 09:51:10', '', 'About', '', 'publish', 'open', 'open', '', 'about', '', '', '2015-08-20 09:51:10', '2015-08-20 09:51:10', '', 0, 'http://evarecruit.localhost/?page_id=28', 0, 'page', '', 0),
(29, 1, '2015-08-20 09:48:57', '2015-08-20 09:48:57', '', 'Jobs', '', 'publish', 'open', 'open', '', 'jobs', '', '', '2015-08-20 10:04:35', '2015-08-20 10:04:35', '', 0, 'http://evarecruit.localhost/?page_id=29', 0, 'page', '', 0),
(30, 1, '2015-08-20 09:48:57', '2015-08-20 09:48:57', '', 'Jobs', '', 'inherit', 'open', 'open', '', '29-revision-v1', '', '', '2015-08-20 09:48:57', '2015-08-20 09:48:57', '', 29, 'http://evarecruit.localhost/uncategorized/29-revision-v1', 0, 'revision', '', 0),
(31, 1, '2015-08-20 09:51:10', '2015-08-20 09:51:10', '', 'About', '', 'inherit', 'open', 'open', '', '28-revision-v1', '', '', '2015-08-20 09:51:10', '2015-08-20 09:51:10', '', 28, 'http://evarecruit.localhost/uncategorized/28-revision-v1', 0, 'revision', '', 0),
(32, 1, '2015-08-20 10:05:27', '2015-08-20 10:05:27', '', 'Services', '', 'inherit', 'open', 'open', '', '25-revision-v1', '', '', '2015-08-20 10:05:27', '2015-08-20 10:05:27', '', 25, 'http://evarecruit.localhost/uncategorized/25-revision-v1', 0, 'revision', '', 0),
(33, 1, '2015-08-21 09:06:21', '2015-08-21 09:06:21', '', 'Urgent! Japanese Bridge Systems Engineer/ Project Manager', '', 'publish', 'closed', 'closed', '', 'urgent-japanese-bridge-systems-engineer-project-manager', '', '', '2015-08-24 04:53:14', '2015-08-24 04:53:14', '', 0, 'http://evarecruit.localhost/?post_type=job&#038;p=33', 0, 'job', '', 0),
(34, 1, '2015-08-21 09:07:26', '2015-08-21 09:07:26', '', 'Urgent! Japanese Bridge Systems Engineer/ Project Manager', '', 'inherit', 'open', 'open', '', '33-autosave-v1', '', '', '2015-08-21 09:07:26', '2015-08-21 09:07:26', '', 33, 'http://evarecruit.localhost/uncategorized/33-autosave-v1', 0, 'revision', '', 0),
(35, 1, '2015-08-24 03:08:47', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2015-08-24 03:08:47', '0000-00-00 00:00:00', '', 0, 'http://evarecruit.localhost/?p=35', 0, 'post', '', 0),
(36, 1, '2015-08-24 03:31:15', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2015-08-24 03:31:15', '0000-00-00 00:00:00', '', 0, 'http://evarecruit.localhost/?post_type=job&p=36', 0, 'job', '', 0),
(37, 1, '2015-08-24 03:40:45', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2015-08-24 03:40:45', '0000-00-00 00:00:00', '', 0, 'http://evarecruit.localhost/?post_type=job&p=37', 0, 'job', '', 0),
(38, 1, '2015-08-24 03:41:28', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2015-08-24 03:41:28', '0000-00-00 00:00:00', '', 0, 'http://evarecruit.localhost/?post_type=job&p=38', 0, 'job', '', 0),
(39, 1, '2015-08-24 03:41:56', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2015-08-24 03:41:56', '0000-00-00 00:00:00', '', 0, 'http://evarecruit.localhost/?post_type=job&p=39', 0, 'job', '', 0),
(40, 1, '2015-08-24 05:01:10', '2015-08-24 05:01:10', '', 'Urgent! Senior PHP Developers - (competitive Salary & Benefits)', '', 'publish', 'closed', 'closed', '', 'urgent-senior-php-developers-competitive-salary-benefits', '', '', '2015-08-24 05:01:20', '2015-08-24 05:01:20', '', 0, 'http://evarecruit.localhost/?post_type=job&#038;p=40', 0, 'job', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `wp_terms`
--

CREATE TABLE IF NOT EXISTS `wp_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  `term_order` int(4) DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=9 ;

--
-- Dumping data for table `wp_terms`
--

INSERT INTO `wp_terms` (`term_id`, `name`, `slug`, `term_group`, `term_order`) VALUES
(1, 'Uncategorized', 'uncategorized', 0, 0),
(2, 'BPO', 'bpo', 0, 0),
(3, 'Communicator', 'communicator', 0, 0),
(4, 'BSE', 'bse', 0, 0),
(5, 'Developer', 'developer', 0, 0),
(6, 'Ho Chi Minh', 'ho-chi-minh', 0, 0),
(7, 'Ha Noi', 'ha-noi', 0, 0),
(8, 'Da Nang', 'da-nang', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `wp_term_relationships`
--

CREATE TABLE IF NOT EXISTS `wp_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `wp_term_relationships`
--

INSERT INTO `wp_term_relationships` (`object_id`, `term_taxonomy_id`, `term_order`) VALUES
(1, 1, 0),
(33, 4, 0),
(33, 6, 0),
(40, 5, 0),
(40, 6, 0);

-- --------------------------------------------------------

--
-- Table structure for table `wp_term_taxonomy`
--

CREATE TABLE IF NOT EXISTS `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=9 ;

--
-- Dumping data for table `wp_term_taxonomy`
--

INSERT INTO `wp_term_taxonomy` (`term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 1),
(2, 2, 'job-position', '', 0, 0),
(3, 3, 'job-position', '', 0, 0),
(4, 4, 'job-position', '', 0, 1),
(5, 5, 'job-position', '', 0, 1),
(6, 6, 'job-location', '', 0, 2),
(7, 7, 'job-location', '', 0, 0),
(8, 8, 'job-location', '', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `wp_usermeta`
--

CREATE TABLE IF NOT EXISTS `wp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=21 ;

--
-- Dumping data for table `wp_usermeta`
--

INSERT INTO `wp_usermeta` (`umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'nickname', 'admin'),
(2, 1, 'first_name', ''),
(3, 1, 'last_name', ''),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'comment_shortcuts', 'false'),
(7, 1, 'admin_color', 'fresh'),
(8, 1, 'use_ssl', '0'),
(9, 1, 'show_admin_bar_front', 'true'),
(10, 1, 'wp_capabilities', 'a:1:{s:13:"administrator";b:1;}'),
(11, 1, 'wp_user_level', '10'),
(12, 1, 'dismissed_wp_pointers', 'wp360_locks,wp390_widgets,wp410_dfw'),
(13, 1, 'show_welcome_panel', '1'),
(15, 1, 'wp_dashboard_quick_press_last_post_id', '35'),
(16, 1, 'wp_user-settings', 'libraryContent=browse&posts_list_mode=list&editor=html&mfold=o'),
(17, 1, 'wp_user-settings-time', '1440042386'),
(18, 1, 'managenav-menuscolumnshidden', 'a:4:{i:0;s:11:"link-target";i:1;s:11:"css-classes";i:2;s:3:"xfn";i:3;s:11:"description";}'),
(19, 1, 'metaboxhidden_nav-menus', 'a:3:{i:0;s:8:"add-post";i:1;s:12:"add-post_tag";i:2;s:15:"add-post_format";}'),
(20, 1, 'session_tokens', 'a:1:{s:64:"432f0cf1723d6518761010eb49a86e847007fac217747922969501f039765067";a:4:{s:10:"expiration";i:1440558526;s:2:"ip";s:9:"127.0.0.1";s:2:"ua";s:76:"Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:40.0) Gecko/20100101 Firefox/40.0";s:5:"login";i:1440385726;}}');

-- --------------------------------------------------------

--
-- Table structure for table `wp_users`
--

CREATE TABLE IF NOT EXISTS `wp_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_pass` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=2 ;

--
-- Dumping data for table `wp_users`
--

INSERT INTO `wp_users` (`ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(1, 'admin', '$P$BP9eW8ynVv94f3Y0AH014gucgLzduR/', 'admin', 'khangld@evolableasia.vn', '', '2015-08-06 02:07:58', '', 0, 'admin');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
